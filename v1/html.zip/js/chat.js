
var dtm = window.parent.document.createElement('script'); dtm.type="text/javascript"; dtm.id = 'ze-snippet'; dtm.src='https://static.zdassets.com/ekr/snippet.js?key=a10966de-b033-459a-991c-f8e79aeb3e7a'; var d = window.parent.document.getElementsByTagName('head')[0]; d.appendChild(dtm); var dtmf = window.parent.document.createElement('script'); dtmf.type="text/javascript"; dtmf.id = '_adobe_dtm_script_footer_tag'; dtmf.text='_satellite.pageBottom();'; var bd = window.parent.document.getElementsByTagName('body')[0]; bd.appendChild(dtmf);


    function setButtonURL() {
        $zopim.livechat.window.show();
    }
    function buttonURL() {
        $zopim.livechat.window.show();
    }
    function toggleChat() {
        $zopim.livechat.window.show();
    }